package UTS_Nisa;

public class siswaNisa {
    String nisnNisa;
    String namaNisa;
    String alamatNisa;
    int tahunNisa;
    double nilaiNisa;

    public siswaNisa(String nisnNisa; String nmNisa; String almtNisa; int thnNisa; double nilaiNisa){
        this.nisnNisa = nisnNisa;
        this.namaNisa = nmNisa;
        this.alamatNisa = almtNisa;
        this.tahunNisa = thnNisa;
        this.nilaiNisa = nilaiNisa;
    }
}
