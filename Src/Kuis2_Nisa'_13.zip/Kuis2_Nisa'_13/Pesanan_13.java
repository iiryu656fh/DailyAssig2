public class Pesanan_13 {
    int kodePesanan13;
    String namaPesanan13;
    int harga13;

    public Pesanan_13 (int a, String b, int d) {
        this.kodePesanan13 = a;
        this.namaPesanan13 = b;
        this.harga13 = d;
    }
}
